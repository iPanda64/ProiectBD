module PlatformaStudiu {
    requires javafx.controls;
    requires javafx.graphics;
    requires java.desktop;
    requires java.sql;
    requires jdk.jshell;

    exports PlatformaStudiu;
}